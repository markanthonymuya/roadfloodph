<?php
	$appId  = 'secret';
	$appSecret = 'secret';
	$accessToken = 'secret';
	$fbPage =  'secret';
?>