<?php

	$appId = "secret";
	$appSecret = "secret";
	$shortCodeFromGlobe = "secret";
?>